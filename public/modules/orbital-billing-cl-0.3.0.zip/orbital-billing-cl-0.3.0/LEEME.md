# Orbital · Facturación Chile 0.3.0

Paquete de integración para Orbital, base Git `3971154d7263feeb5a9004f8193e4234b0ef099b`.
No es un plugin WordPress. En Desktop/orbital los cambios ya están integrados.

Para otro checkout de la misma base, respaldar/revisar sus cambios, copiar los archivos de overlay/ conservando rutas y revisar/aplicar integration.patch (`git apply --check` antes de aplicar). Si la base es distinta, resolver la integración manualmente: no sobrescribir trabajo existente. Instalar dependencias con npm ci en raíz y services/payload, ejecutar las verificaciones de modules/billing-cl/VALIDACION.md, migrar una base respaldada y desplegar Astro/Payload/worker. Habilitar después desde /app/modulos.

El parche contiene configuración, dependencias, catálogo y navegación. overlay contiene el motor, conectores, pruebas y paquete complementario de la tienda Payload. Los fixtures son generadores sintéticos; no hay credenciales reales.

Consultar overlay/modules/billing-cl/README.md y VALIDACION.md. Requiere certificación oficial del SII; producción no habilitada. El .tgz de Payload exige conectar los helpers al adaptador de pagos de la tienda real.
